/*
 * [The "MIT licence"]
 * Copyright (c) 2022 © Radha Krushna
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/**
 * 
 * @author Maharna's Tech
 * @time 2022/10/22  10.00AM IST
 * */


package com.keystore;


import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.Button;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.widget.Switch;
import android.widget.Toast;
import android.text.Html;
import android.graphics.Color;
import android.content.DialogInterface.OnClickListener;
import android.app.AlertDialog.Builder;
import android.app.AlertDialog;
import com.mt.*;


public class MainActivity extends Activity {
	
	private String keyPassword = "";
	private String storePassword = "";
	private String commonName = "";
	private String OrganizationUnit = "";
	private String OrganizationName = "";
	private String stateName = "";
	private String CountryCode = "";
	private String city = "";
	private double expire = 0;
	private String save = "";
	private String app_directory = "";
	private String alias = "";
	

	

	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.activity_main);
		Toast.makeText(getApplication(), "Made by Krushna❤️", Toast.LENGTH_SHORT).show();
		Builder MT= new Builder(this);
		MT.setTitle("Generate Key");
		LinearLayout layout = new LinearLayout(this);
	    layout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		final ScrollView scroll = new ScrollView(this);
		scroll.setLayoutParams(lp);
		layout.setPadding(45, 10, 45, 10);
		TextView txt = new TextView(this);
		txt.setText("Alias");
		txt.setTextColor(0xFF0096FF);
		layout.addView(txt);
		final EditText edittext_alias = new  EditText(this);
		edittext_alias.setHint("Enter Alias");
		layout.setPadding(45, 10, 45, 10);
		edittext_alias.setLayoutParams(lp);
		layout.addView(edittext_alias);
		TextView txt1 = new TextView(this);
		txt1.setText("KeyStore Password");
		txt1.setTextColor(0xFF0096FF);
		layout.addView(txt1);
		final EditText edittext_password = new EditText(this);
		edittext_password.setHint("Enter KeyStore Password");
		layout.setPadding(45, 10, 45, 10);
		edittext_password.setLayoutParams(lp);
		layout.addView(edittext_password);
		TextView txt10 = new TextView(this);
		txt10.setText("Private Key Password");
		txt10.setTextColor(0xFF0096FF);
		layout.addView(txt10);
		final EditText edittext_keypassword = new EditText(this);
		edittext_keypassword.setHint("Enter Private Key Password");
		layout.setPadding(45, 10, 45, 10);
		edittext_keypassword.setLayoutParams(lp);
		layout.addView(edittext_keypassword);
		TextView title1 = new TextView(this);
		title1.setText("Certificate");
	    title1.setTypeface(title1.getTypeface(), Typeface.BOLD);
		title1.setPadding(10, 10, 10, 10);
		title1.setGravity(Gravity.CENTER);
		title1.setTextColor(Color.BLACK);
		title1.setTextSize(25);
		layout.addView(title1);
		TextView txt2 = new TextView(this);
		txt2.setText("Validity");
		txt2.setTextColor(0xFF0096FF);
		layout.addView(txt2);
		final EditText edittext_validity = new EditText(this);
		edittext_validity.setHint("Enter Validity eg.25");
		edittext_validity.setText("25");
		layout.setPadding(45, 10, 45, 10);
		edittext_validity.setLayoutParams(lp);
		layout.addView(edittext_validity);
		TextView txt3 = new TextView(this);
		txt3.setText("Name");
		txt3.setTextColor(0xFF0096FF);
		layout.addView(txt3);
		final EditText edittext_name = new EditText(this);
		edittext_name.setHint("Enter Name");
		layout.setPadding(45, 10, 45, 10);
		edittext_name.setLayoutParams(lp);
		layout.addView(edittext_name);
		TextView txt4 = new TextView(this);
		txt4.setText("Organization Unit");
		txt4.setTextColor(0xFF0096FF);
		layout.addView(txt4);
		final EditText edittext_orgunit = new EditText(this);
		edittext_orgunit.setHint("Enter Organization Unit");
		layout.setPadding(45, 10, 45, 10);
		edittext_orgunit.setLayoutParams(lp);
		layout.addView(edittext_orgunit);
		TextView txt5 = new TextView(this);
		txt5.setTextColor(0xFF0096FF);
		txt5.setText("Organization");
		layout.addView(txt5);
		final EditText edittext_org = new EditText(this);
		edittext_org.setHint("Enter Organization");
		layout.setPadding(45, 10, 45, 10);
		edittext_org.setLayoutParams(lp);
		layout.addView(edittext_org);
		TextView txt6 = new TextView(this);
		txt6.setTextColor(0xFF0096FF);
		txt6.setText("City/Locality");
		layout.addView(txt6);
		final EditText edittext_city = new EditText(this);
		edittext_city.setHint("Enter City/Locality");
		layout.setPadding(45, 10, 45, 10);
		edittext_city.setLayoutParams(lp);
		layout.addView(edittext_city);
		TextView txt7 = new TextView(this);
		txt7.setTextColor(0xFF0096FF);
		txt7.setText("State/Province");
		layout.addView(txt7);
		final EditText edittext_state = new EditText(this);
		edittext_state.setHint("Enter State/Province");
		layout.setPadding(45, 10, 45, 10);
		edittext_state.setLayoutParams(lp);
		layout.addView(edittext_state);
		TextView txt8 = new TextView(this);
		txt8.setTextColor(0xFF0096FF);
		txt8.setText("Country");
		layout.addView(txt8);
		final EditText edittext_country = new EditText(this);
		edittext_country.setHint("Enter Country Name eg. for India(IN)");
		edittext_country.setText("IN");
		layout.setPadding(45, 10, 45, 10);
		edittext_country.setLayoutParams(lp);
		layout.addView(edittext_country);
		TextView txt9 = new TextView(this);
		txt9.setText("© Radha Krushna");
		txt9.setGravity(Gravity.CENTER);
		layout.addView(txt9);
		layout.addView(scroll);
		MT.setView(layout);
		
	    MT.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dia, int which) {
					if (edittext_alias.getText().toString().equals("") || (edittext_password.getText().toString().equals("") || (edittext_validity.getText().toString().equals("") || (edittext_name.getText().toString().equals("") || (edittext_orgunit.getText().toString().equals("") || (edittext_org.getText().toString().equals("") || (edittext_city.getText().toString().equals("") || (edittext_state.getText().toString().equals("") || edittext_country.getText().toString().equals(""))))))))) {
						Toast.makeText(getApplication(), "Complete All Information", Toast.LENGTH_SHORT).show();
					}
					else {
						alias = edittext_alias.getText().toString();
						keyPassword = edittext_keypassword.getText().toString();
						storePassword = edittext_password.getText().toString();
						commonName = edittext_name.getText().toString();
						OrganizationUnit = edittext_orgunit.getText().toString();
						OrganizationName = edittext_org.getText().toString();
						stateName = edittext_state.getText().toString();
						CountryCode = edittext_country.getText().toString();
						city = edittext_city.getText().toString();
						expire = Double.parseDouble(edittext_validity.getText().toString());
						save = app_directory.concat("release_key.jks");
						KeyStore.Builder builder = new KeyStore.Builder();
						builder.setAlias(alias);
						builder.setKeyPassword(keyPassword);
						builder.setStorePassword(storePassword);
						builder.setCommonName(commonName);
						builder.setOrganizationName(OrganizationName);
						builder.setOrganizationUnit(OrganizationUnit);
						builder.setStateName(stateName);
						builder.setValidityYears((int)expire);
						builder.setCityOrLocalityName(city);
						builder.setCountryCode(CountryCode);
						builder.setStoreType(KeyStore.Type.JKS);
						builder.setKeySize(KeyStore.Size.S_1024);
						builder.setSigAlgorithm(KeyStore.SigAlgorithm.SHA1WITHRSA);
						builder.setKeyAlgorithm(KeyStore.Algorithm.RSA);
						builder.setOutputFile(new java.io.File(save));
						try {
							KeyStore.generate(builder);
						} catch (Exception e) {
							Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
						}
						if (FileUtil.isExistFile(save)) {
							Toast.makeText(getApplication(), "Success - ".concat(save.replace(FileUtil.getExternalStorageDir(), "")), Toast.LENGTH_SHORT).show();

						}
					}
				}
			});
		MT.setNegativeButton("Cancel", null);
		MT.show();
		}
		}
